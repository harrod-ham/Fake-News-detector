## About NODE.js API

This project is created to teach you how to create a Restful CRUD API with Node.js, Express and MongoDB.

If you want to learn how the project is developed. You can visit https://www.youtube.com/watch?v=FPYlicctQMM&list=PLbKN8A2wssqUlVHRBeJIgIvkbyrX4kR0V or https://www.youtube.com/watch?v=9OfL9H6AmhQ&feature=youtu.be

### API Features

The application can create, read, update and delete data, for example: products, in a database. 
